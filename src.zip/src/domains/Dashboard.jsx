const Dashboard = () => {
    return (
        <div className=" main ">
           Dashboard
        </div>
    )
}

export default Dashboard 