const Dashboard = () => {
    return (
        <div className=" main ">
           Welcome To Planboard
        </div>
    )
}

export default Dashboard 