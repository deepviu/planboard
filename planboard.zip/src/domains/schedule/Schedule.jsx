const Schedule = () => {
    return (
        <div className="main  w3-border"> 
           Schedule 
        </div>
    ) 
}

export default Schedule 