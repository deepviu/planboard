export const Wgt_Summ_National_Data = [ 
      {
      id: 1, 
      summ_entity_id:1,  
      summ_entity_name:1, 
      summ_lly_fy: "21-22", 
      summ_lly_sale_value: "480",
      summ_ly_fy: "22-23",
      summ_ly_sale_value: "600", 
      summ_cy_fy: "23-24",
      summ_cy_target_v1_value: "876",
      summ_cy_target_v2_value: "876",
      summ_cy_target_v1_percentage: "46",
      summ_cy_target_v2_percentage: "46", 
      summ_cy_sale_ytd_value: "60", 
      summ_cy_sale_ytd_percentage: "12",
    },  
  ];