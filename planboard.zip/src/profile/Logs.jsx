const Logs = () => {
    return (
        <div className="main  w3-border"> 
           Logs 
        </div>
    ) 
}

export default Logs 