
export { default as Account } from './Account'; 
export { default as Profile } from './Profile';
export { default as Notifications } from './Notifications';
export { default as Logs } from './Logs';
export { default as Verifyemail } from './Verifyemail';
export { default as Verifyphone } from './Verifyphone';
export { default as Verifyprofile } from './Verifyprofile';  