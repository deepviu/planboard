const Verifyphone = () => {
    return (
        <div className="main  w3-border"> 
           Verifyphone 
        </div>
    ) 
}

export default Verifyphone 