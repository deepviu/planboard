const Profile = () => {
    return (
        <div className="main  w3-border"> 
           Profile 
        </div>
    ) 
}

export default Profile 