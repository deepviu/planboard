const Verifyprofile = () => {
    return (
        <div className="main  w3-border"> 
           Verifyprofile 
        </div>
    ) 
}

export default Verifyprofile 