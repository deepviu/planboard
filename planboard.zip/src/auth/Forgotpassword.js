const Forgotpassword = () => {
    return (
        <div className="main  w3-border"> 
           Forgotpassword 
        </div>
    ) 
}

export default Forgotpassword 