   
export { default as Login } from './Login';  
export { default as Register } from './Register'; 
export { default as Forgotpassword } from './Forgotpassword';   